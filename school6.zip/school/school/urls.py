"""school URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include
from django.conf import settings
from django.conf.urls.static import static
from webapp import views
urlpatterns = [
    path('admin/', admin.site.urls),
    path('list/', views.home,name='home'),
    path('sample/', views.samp,),

    path('form/', views.frm, name='form'),
    path('retrive/<int:id>', views.org_retrive, name='retrive'),
    path('update/<int:id>', views.org_update, name='update'),
    path('delete/<int:id>', views.org_delete, name='delete'),
    path('Admision/', views.AF),
    path('thank/', views.tqs),
    path('status/', views.stat),


    path('register/', views.registerPage, name="register"),
	path('', views.loginPage, name="login"),
	path('logout/', views.logoutUser, name="logout"),

    path('hom2/', views.home2, name="hme"),

    path('xresults/',views.rs10),
    path('ixresults/',views.rs9),
    path('viiiresults/',views.rs8),
    path('viiresults/',views.rs7),
    path('viresults/',views.rs6),

    path('xatt/',views.at10),
    path('9att/',views.at9),
    path('8att/',views.at8),
    path('7att/',views.at7),
    path('6att/',views.at6),

    path('grra/',views.Gra),
    path('grrb/',views.Grb),
    path('grrc/',views.Grc),

    path('admi/',views.adm),
    path('feedback/',views.fdview),
    path('about/',views.about),
    path('tq/',views.tq)

]
urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

