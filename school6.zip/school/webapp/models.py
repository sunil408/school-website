from django.db import models
from django.urls import reverse
from django_countries.fields import CountryField
from django.utils import timezone
import datetime

# Create your models here.

class sunil(models.Model):

    Gendar = models.CharField(max_length=1)
    def __str__(self):
        return self.Gendar
    def get_absolute_url(self):
        return reverse('retrive', kwargs={"id": self.id})



class bi(models.Model):
    Admission = models.IntegerField()
    Name = models.CharField(max_length=50)
    cls=(('X',"x"),('IX',"ix"),('VIII',"viii"),('VII',"vii"),('VI',"vi"))
    Class = models.CharField(max_length=10,choices=cls,default="VI")
    Village = models.CharField(max_length=50)
    Mandal = models.CharField(max_length=50)
    Gender=models.ForeignKey(sunil,on_delete=models.CASCADE)
    def __str__(self):
        return self.Name
    def get_absolute_url(self):
        return reverse('retrive', kwargs={"id": self.id})
class admi(models.Model):
    Student_Full_Name=models.CharField(max_length=30,blank=True)
    Father_Name=models.CharField(max_length=50)
    gen=(('M',"M"),('F',"F"))
    Gender=models.CharField(max_length=2,choices=gen)
    User_Name=models.CharField(max_length=20,help_text='(Use Characters, Numbers and @ # $ % > .)' )
    cc=(('x',"X"),('ix',"IX"),('viii',"VIII"),('vii',"VII"),('vi',"VI"))
    Class=models.CharField(max_length=5,choices=cc,default="vi")

    Nationality=CountryField()
    fac=(('Day',"Day"),('Residential',"Residential"),('Semi-Residential',"Semi-Residential"))
    Facility=models.CharField(max_length=20,choices=fac,default="Day")
    Email=models.EmailField()
    address=models.CharField(max_length=50)
    sn=(('Processing',"Processing"),('Pending',"Pending"),('Admission Confirm',"Admission Conform"),('Reject',"Reject"))
    Status=models.CharField(max_length=20,choices=sn,default="Processing")
    check_me_out = models.BooleanField(default=False)
    def __str__(self):
        return self.Student_Full_Name
class results10(models.Model):
    Email=models.EmailField()
    English=models.IntegerField()
    Mathematics=models.IntegerField()
    Science=models.IntegerField()
    Social=models.IntegerField()
    Quiz=models.IntegerField()
    Drawing=models.IntegerField()
    st=(('Pass',"Pass"),('Fail',"Fail"))
    Total = models.IntegerField()
    Status=models.CharField(max_length=10,choices=st)
    gr = (('A', "A"), ('B', "B"), ('C', "C"), ('D', "D"))
    Grade=models.CharField(max_length=1,choices=gr)

class results9(models.Model):
    Email=models.EmailField()
    English=models.IntegerField()
    Mathematics=models.IntegerField()
    Science=models.IntegerField()
    Social=models.IntegerField()
    Quiz=models.IntegerField()
    Drawing=models.IntegerField()
    Total = models.IntegerField()
    st=(('Pass',"Pass"),('Fail',"Fail"))
    Status=models.CharField(max_length=10,choices=st)
    gr = (('A', "A"), ('B', "B"), ('C', "C"), ('D', "D"))
    Grade=models.CharField(max_length=1,choices=gr)

class results8(models.Model):
    Email=models.EmailField()
    English=models.IntegerField()
    Mathematics=models.IntegerField()
    Science=models.IntegerField()
    Social=models.IntegerField()
    Quiz=models.IntegerField()
    Drawing=models.IntegerField()
    Total = models.IntegerField()
    st=(('Pass',"Pass"),('Fail',"Fail"))
    Status=models.CharField(max_length=10,choices=st)
    gr = (('A', "A"), ('B', "B"), ('C', "C"), ('D', "D"))
    Grade=models.CharField(max_length=1,choices=gr)

class results7(models.Model):
    Email=models.EmailField()
    English=models.IntegerField()
    Mathematics=models.IntegerField()
    Science=models.IntegerField()
    Social=models.IntegerField()
    Quiz=models.IntegerField()
    Drawing=models.IntegerField()
    Total = models.IntegerField()
    st=(('Pass',"Pass"),('Fail',"Fail"))
    Status=models.CharField(max_length=10,choices=st)
    gr=(('A',"A"),('B',"B"),('C',"C"),('D',"D"))
    Grade=models.CharField(max_length=1,choices=gr)

class results6(models.Model):
    Email=models.EmailField()
    English=models.IntegerField()
    Mathematics=models.IntegerField()
    Science=models.IntegerField()
    Social=models.IntegerField()
    Quiz=models.IntegerField()
    Drawing=models.IntegerField()
    st=(('Pass',"Pass"),('Fail',"Fail"))
    Total=models.IntegerField()
    Status=models.CharField(max_length=10,choices=st)
    gr = (('A', "A"), ('B', "B"), ('C', "C"), ('D', "D"))
    Grade=models.CharField(max_length=1,choices=gr)

class att10(models.Model):
    Email=models.EmailField()
    Name=models.CharField(max_length=20)
    mm=(('January',"January"),('February',"February"),('March',"March"),('April',"April"),('May',"May"),('June',"June"),('July',"July"),('August',"August"),('September',"September"),('October',"October"),('November',"NOvember"),('December',"December"))
    Month=models.CharField(max_length=15,choices=mm)
    Percentage = models.IntegerField()
    gr = (('A', "A"), ('B', "B"), ('C', "C"))
    Grade=models.CharField(max_length=1,choices=gr)

class att9(models.Model):
    Email=models.EmailField()
    Name=models.CharField(max_length=20)
    mm=(('January',"January"),('February',"February"),('March',"March"),('April',"April"),('May',"May"),('June',"June"),('July',"July"),('August',"August"),('September',"September"),('October',"October"),('November',"NOvember"),('December',"December"))
    Month=models.CharField(max_length=15,choices=mm)
    Percentage = models.IntegerField()
    gr = (('A', "A"), ('B', "B"), ('C', "C"))
    Grade=models.CharField(max_length=1,choices=gr)
class att8(models.Model):
    Email=models.EmailField()
    Name=models.CharField(max_length=20)
    mm=(('January',"January"),('February',"February"),('March',"March"),('April',"April"),('May',"May"),('June',"June"),('July',"July"),('August',"August"),('September',"September"),('October',"October"),('November',"NOvember"),('December',"December"))
    Month=models.CharField(max_length=15,choices=mm)
    Percentage = models.IntegerField()
    gr = (('A', "A"), ('B', "B"), ('C', "C"))
    Grade=models.CharField(max_length=1,choices=gr)

class att7(models.Model):
    Email=models.EmailField()
    Name=models.CharField(max_length=20)
    mm=(('January',"January"),('February',"February"),('March',"March"),('April',"April"),('May',"May"),('June',"June"),('July',"July"),('August',"August"),('September',"September"),('October',"October"),('November',"NOvember"),('December',"December"))
    Month=models.CharField(max_length=15,choices=mm)
    Percentage = models.IntegerField()
    gr = (('A', "A"), ('B', "B"), ('C', "C"))
    Grade=models.CharField(max_length=1,choices=gr)
class att6(models.Model):
    Email=models.EmailField()
    Name=models.CharField(max_length=20)
    mm=(('January',"January"),('February',"February"),('March',"March"),('April',"April"),('May',"May"),('June',"June"),('July',"July"),('August',"August"),('September',"September"),('October',"October"),('November',"NOvember"),('December',"December"))
    Month=models.CharField(max_length=15,choices=mm)
    Percentage=models.IntegerField()
    gr = (('A', "A"), ('B', "B"), ('C', "C"))
    Grade=models.CharField(max_length=1,choices=gr)


class Ga(models.Model):
    Email=models.EmailField()
    Name=models.CharField(max_length=50)
    gr = (('A', "A"), ('B', "B"), ('C', "C"))
    Studies=models.CharField(max_length=1,choices=gr)
    Sports=models.CharField(max_length=1,choices=gr)
    Attitude=models.CharField(max_length=1,choices=gr)
    OverallStatus = models.CharField(max_length=1, choices=gr)

class Gb(models.Model):
    Email=models.EmailField()
    Name=models.CharField(max_length=50)
    gr = (('A', "A"), ('B', "B"), ('C', "C"))
    Studies=models.CharField(max_length=1,choices=gr)
    Sports=models.CharField(max_length=1,choices=gr)
    Attitude=models.CharField(max_length=1,choices=gr)
    OverallStatus = models.CharField(max_length=1, choices=gr)

class Gc(models.Model):
    Email=models.EmailField()
    Name=models.CharField(max_length=50)
    gr = (('A', "A"), ('B', "B"), ('C', "C"))
    Studies=models.CharField(max_length=1,choices=gr)
    Sports=models.CharField(max_length=1,choices=gr)
    Attitude=models.CharField(max_length=1,choices=gr)
    OverallStatus=models.CharField(max_length=1,choices=gr)

class fdback(models.Model):
    Name=models.CharField(max_length=30)
    Email=models.EmailField()
    Comments=models.TextField()
