from .models import bi,admi,fdback
from django import forms
#from captcha.fields import ReCaptchaField
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

class newschool(forms.ModelForm):
    class Meta:
        model=bi
        fields='__all__'

class admiForm(forms.ModelForm):

    class Meta:
        model=admi
        fields=('id','Student_Full_Name','Father_Name','Gender','User_Name','Class','Facility','address','Email','Nationality','check_me_out')



class CreateUserForm(UserCreationForm):
	class Meta:
		model = User
		fields = ['username', 'email', 'password1', 'password2']
class fdform(forms.ModelForm):
    class Meta:
        model=fdback
        fields='__all__'