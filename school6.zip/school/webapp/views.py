from django.shortcuts import render,get_object_or_404,redirect
from django.http import HttpResponseRedirect
from .models import bi,admi,results10,results9,results8,results7,results6,att10,att6,att7,att8,att9,Ga,Gb,Gc
from .forms import newschool,admiForm,fdform

from django.db.models import Q

from django.contrib.auth import authenticate, login, logout
# Create your views here.
from django.contrib.auth.decorators import login_required
from .forms import  CreateUserForm
from django.contrib import messages
# Create your views here.
@login_required
def home(request):
    lis=bi.objects.all()
    return render(request,'scl.html',{'lis':lis})
def frm(request):
    form=newschool(request.POST or None ,request.FILES or None )
    if form.is_valid():
        instance=form.save()
        instance.save()
        return HttpResponseRedirect('/')
    context={'form':form}
    return render(request,'create.html',context)
@login_required
def org_retrive(request,id=None):
    instance=get_object_or_404(bi,id=id)
    context={'instance':instance}
    return render(request,'retrive.html',context)
@login_required
def org_update(request,id=None):
	instance = get_object_or_404(bi,id=id)
	form = newschool(request.POST or None,request.FILES or None ,instance=instance)
	if form.is_valid():
		instance = form.save()
		instance.save()
		return HttpResponseRedirect(instance.get_absolute_url())
	context ={'instance':instance,'form':form}
	return  render (request,"update.html" , context)
@login_required
def samp(request):
    lis = bi.objects.all()
    return render(request, 'sample.html', {'lis': lis})
def org_delete(request,id=None):
	instance =get_object_or_404(bi,id=id)
	instance.delete()
	return render(request,"delete.html")


def AF(request):
    if request.method=="POST":
        forma=admiForm(request.POST)
        if forma.is_valid():
            forma.save(commit=True)
            return HttpResponseRedirect('/thank')
    else:
        forma=admiForm()
    return render(request,'admission_form.html',{'forma':forma})
def tqs(request):
    return render(request,'thankyou.html')

def stat(request):

    if request.method=="POST":
        mii=request.POST['st']
        if mii:
            match=admi.objects.filter(Q(User_Name=mii)|Q(Email=mii))
            if match:
                return render(request,'status.html',{'sr':match})
            else:
                messages.error(request,'No Results Found.')
        else:
            return HttpResponseRedirect('/status/')
    return render(request,'status.html')


def registerPage(request):
    if request.user.is_authenticated:
        return redirect('hme')
    else:
        form = CreateUserForm()
        if request.method == 'POST':
            form = CreateUserForm(request.POST)
            if form.is_valid():
                form.save()
                user = form.cleaned_data.get('username')
                messages.success(request, 'Account was created for ' + user)

                return redirect('login')

        context = {'form': form}
        return render(request, 'user/register.html', context)
@login_required()
def home2(request):
    return render(request,'user/home2.html')

def loginPage(request):
	if request.user.is_authenticated:
		return redirect('hme')
	else:
		if request.method == 'POST':
			username = request.POST.get('username')
			password =request.POST.get('password')

			user = authenticate(request, username=username, password=password)

			if user is not None:
				login(request, user)
				return redirect('hme')
			else:
				messages.info(request, 'Username OR password is incorrect')

		context = {}
		return render(request, 'user/login.html', context)

def logoutUser(request):
	logout(request)
	return redirect('login')

def rs10(request):
    if request.method=="POST":
        x=request.POST['xx']
        if x:
            ten=results10.objects.filter(Q(Email=x))
            if ten:
                return render(request,'r10.html',{'t':ten})
            else:
                messages.error(request, 'No Results Found.')
        else:
            return HttpResponseRedirect('/xresults/')
    return render(request, 'r10.html')

def rs9(request):
    if request.method=="POST":
        x=request.POST['ix']
        if x:
            ten=results9.objects.filter(Q(Email=x))
            if ten:
                return render(request,'r9.html',{'t':ten})
            else:
                messages.error(request, 'No Results Found.')
        else:
            return HttpResponseRedirect('/ixresults/')
    return render(request, 'r9.html')

def rs8(request):
    if request.method=="POST":
        x=request.POST['viii']
        if x:
            ten=results8.objects.filter(Q(Email=x))
            if ten:
                return render(request,'r8.html',{'t':ten})
            else:
                messages.error(request, 'No Results Found.')
        else:
            return HttpResponseRedirect('/viiiresults/')
    return render(request, 'r8.html')

def rs7(request):
    if request.method=="POST":
        x=request.POST['vii']
        if x:
            ten=results7.objects.filter(Q(Email=x))
            if ten:
                return render(request,'r7.html',{'t':ten})
            else:
                messages.error(request, 'No Results Found.')
        else:
            return HttpResponseRedirect('/viiresults/')
    return render(request, 'r7.html')


def rs6(request):
    if request.method=="POST":
        x=request.POST['vi']
        if x:
            ten=results6.objects.filter(Q(Email=x))
            if ten:
                return render(request,'r6.html',{'t':ten})
            else:
                messages.error(request, 'No Results Found.')
        else:
            return HttpResponseRedirect('/viresults/')
    return render(request, 'r6.html')

def at10(request):
    if request.method=="POST":
        x=request.POST['at10']
        if x:
            ten=att10.objects.filter(Q(Email=x))
            if ten:
                return render(request,'att10.html',{'t':ten})
            else:
                messages.error(request, 'No Results Found.')
        else:
            return HttpResponseRedirect('/xatt/')
    return render(request, 'att10.html')

def at9(request):
    if request.method=="POST":
        x=request.POST['at9']
        if x:
            ten=att9.objects.filter(Q(Email=x))
            if ten:
                return render(request,'att9.html',{'t':ten})
            else:
                messages.error(request, 'No Results Found.')
        else:
            return HttpResponseRedirect('/9att/')
    return render(request, 'att9.html')

def at8(request):
    if request.method=="POST":
        x=request.POST['at8']
        if x:
            ten=att8.objects.filter(Q(Email=x))
            if ten:
                return render(request,'att8.html',{'t':ten})
            else:
                messages.error(request, 'No Results Found.')
        else:
            return HttpResponseRedirect('/8att/')
    return render(request, 'att8.html')

def at7(request):
    if request.method=="POST":
        x=request.POST['at7']
        if x:
            ten=att7.objects.filter(Q(Email=x))
            if ten:
                return render(request,'att7.html',{'t':ten})
            else:
                messages.error(request, 'No Results Found.')
        else:
            return HttpResponseRedirect('/7att/')
    return render(request, 'att7.html')
def at6(request):
    if request.method=="POST":
        x=request.POST['at6']
        if x:
            ten=att6.objects.filter(Q(Email=x))
            if ten:
                return render(request,'att6.html',{'t':ten})
            else:
                messages.error(request, 'No Results Found.')
        else:
            return HttpResponseRedirect('/6att/')
    return render(request, 'att6.html')

def Gra(request):
    if request.method == "POST":
        x = request.POST['graa']
        if x:
            ten = Ga.objects.filter(Q(Email=x))
            if ten:
                return render(request, 'gra.html', {'t': ten})
            else:
                messages.error(request, 'No Results Found.')
        else:
            return HttpResponseRedirect('/grra/')
    return render(request, 'gra.html')

def Grb(request):
    if request.method == "POST":
        x = request.POST['grbb']
        if x:
            ten = Gb.objects.filter(Q(Email=x))
            if ten:
                return render(request, 'grb.html', {'t': ten})
            else:
                messages.error(request, 'No Results Found.')
        else:
            return HttpResponseRedirect('/grrb/')
    return render(request, 'grb.html')

def Grc(request):
    if request.method == "POST":
        x = request.POST['grcc']
        if x:
            ten = Gc.objects.filter(Q(Email=x))
            if ten:
                return render(request, 'grc.html', {'t': ten})
            else:
                messages.error(request, 'No Results Found.')
        else:
            return HttpResponseRedirect('/grrc/')
    return render(request, 'grc.html')

def adm(request):
    return render(request,'admi.html')
def fdview(request):
    form = fdform(request.POST or None, request.FILES or None)
    if form.is_valid():
        instance = form.save()
        instance.save()
        return HttpResponseRedirect('/tq')
    context = {'form': form}
    return render(request, 'feedback.html', context)
def about(request):
    return render(request,'about.html')
def tq(request):
    return render(request,'tq.html')
